ScrollShot Android 原生 UI V4 · 自适应排版修正版
=================================================

本版本针对小屏宽度下文字、状态胶囊、箭头和诊断工具互相挤压的问题进行调整。

主要改动：
- 权限行改用明确的图标 / 文案 / 状态 / 箭头列布局，图标与箭头固定，文案弹性缩放。
- 权限状态胶囊缩小内边距，文案字号限定在更适合移动端的范围。
- 品牌标题自动缩放，避免窄屏顶端名称截断。
- 诊断卡片改为内容驱动高度，副文案允许最多两行，不再强制单行截断。
- 垃圾桶与开关保留独立列，不再覆盖诊断说明。
- 根布局保留 ScrollView，屏幕高度不足时可上下滚动，不裁掉下方工具卡片。

安装：
1. 将 res/layout/activity_scrollshot.xml 复制到 app/src/main/res/layout/。
2. 将 res/drawable/、res/drawable-nodpi/、res/color/ 下资源复制到同名目录。
3. 页面使用 setContentView(R.layout.activity_scrollshot) 加载。
4. 将原工程的点击监听和状态更新逻辑重新绑定到保留的控件 ID。

保留的核心 ID：
btnStartScrollShot, btnOneTapAuthorize, rowAccessibility, rowOverlayPermission,
rowNotificationPermission, rowManualStitch, rowViewLastLongImage,
btnClearDiagnosticLogs, switchDiagnosticMode, tvAccessibilityStatus,
tvOverlayPermissionStatus, tvNotificationStatus。

适配说明：
- ScrollView 负责高度不足时的完整滚动；并非强制把所有内容塞进一个屏幕。
- android:fitsSystemWindows="true" 用于常见状态栏 inset 处理；若原 Activity 已自行消费 WindowInsets，需避免重复添加顶部 inset。
- 图标 PNG 使用 drawable-nodpi，防止 Android 按密度错误二次缩放。
- 原生 XML 通过半透明渐变、白色描边与 elevation 模拟玻璃层次；实时 backdrop blur 仍需 Activity 侧额外代码。
- 本包 XML 已通过语法解析，但未在你的实际 Android 工程中完成 Gradle 编译或真机验证。

V4.1 PATCH: Replaced the trash icon with a complete transparent PNG extracted from the approved reference. The ImageButton touch area is 32x40dp with zero internal padding so the bin outline is not clipped.

V4.1 TRASH FIX: The trash icon asset is re-extracted from the approved complete reference image, with the whole bin outline and base preserved. The ImageButton is 32x40dp with zero internal padding and fitCenter scaling.
